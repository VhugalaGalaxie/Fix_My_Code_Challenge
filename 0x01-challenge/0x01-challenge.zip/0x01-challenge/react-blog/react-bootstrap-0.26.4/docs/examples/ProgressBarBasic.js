const progressInstance = (
  <ProgressBar now={60} />
);

React.render(progressInstance, mountNode);
